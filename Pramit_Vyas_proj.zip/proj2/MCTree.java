package proj2;

import java.util.ArrayList;
import java.util.HashMap;

public class MCTree<E> 
{
	MCNode<E> root;
	int size;
}
