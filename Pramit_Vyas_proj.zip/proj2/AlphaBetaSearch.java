package proj2;

/**
 * Minimax checkers agent that utilizes alpha-beta pruning to increase efficiency
 *
 * @author PRamit Vyas
 */
public class AlphaBetaSearch {
    private CheckersData board;

    // An instance of this class will be created in the Checkers.Board
    // It would be better to keep the default constructor.

    public void setCheckersData(CheckersData board) {
        this.board = board;
    }

    /**
     * An integer representing the tree depth at which the agent will stop searching and return an
     * evaluation of the current state.
     */
    private static final int MAX_DEPTH = 10;

    private double maxValue(CheckersData state, double d, double a, double b) {
        if (isTerminal(state) == 1 || isTerminal(state) == 0) {
            return isTerminal(state);
        }
        double values = Double.NEGATIVE_INFINITY;
        for (CheckersMove ch : state.getLegalMoves(CheckersData.BLACK))
        {
            CheckersData temp = state;
            temp.makeMove(ch);

            if (d < MAX_DEPTH) {



                values = Math.max(maxValue(temp,d + 1, a, b), values);

            } else {
                values = Math.max(1000, values);
            }
            a = Math.max(a, values);

            if (values >= b) {
                break;
            }
        }
        return values;
    }

    private double minValue(CheckersData state, double d, double a, double b) {
        if (isTerminal(state) == 1 || isTerminal(state) == 0) {
            return isTerminal(state);
        }
        double values = Double.POSITIVE_INFINITY;
        for (CheckersMove ch : state.getLegalMoves(CheckersData.RED))
        {
            CheckersData temp = state;
            temp.makeMove(ch);

            if (d < MAX_DEPTH) {
                values = Math.min(maxValue(temp,d + 1, a, b), values);

            } else {
                values = Math.min(10000, values);
            }
            b = Math.min(b, values);

            if (values <= a) {
                break;
            }
        }
        return values;

    }
    /**
     * You need to implement the Alpha-Beta pruning algorithm here to
     * find the best move at the current stage.
     * The input parameter legalMoves contains all the possible moves.
     * It contains four integers:  fromRow, fromCol, toRow, toCol
     * which represents a move from (fromRow, fromCol) to (toRow, toCol).
     * It also provides a utility method `isJump` to see whether this
     * move is a jump or a simple move.
     *
     * @param legalMoves All the legal moves for the agent at the current step.
     */
    public CheckersMove makeMove(CheckersMove[] legalMoves) {
        CheckersMove result = null;
        double resultValue = Double.NEGATIVE_INFINITY;

        for (CheckersMove move : legalMoves) {
            CheckersData temp = board;
            temp.makeMove(move);

            double value = minValue(board,0, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY );
            if (value > resultValue) {
                result = move;
                resultValue = value;
            }
        }

        CheckersData temp = board;
        temp.makeMove(result);

        return result;
    }

    private static double isTerminal(CheckersData state) {
    	boolean b = false;
    	boolean c = false;
    	double c1 =0;
    	double c2=0;
    	for(int i = 0; i<state.board.length;i++) {
    		for(int j = 0; j < state.board.length; j++) {
    			if(state.board[i][j] == state.BLACK || state.board[i][j] == state.BLACK_KING) {
    				b = true;
    				c1++;
    			}
    			if(state.board[i][j] == state.RED || state.board[i][j] == state.RED_KING) {
    				c = true;
    				c2++;
    			}
    		}
    	}
        if(b && !c) {
        	return 1;
        }
        if(c && !b) {
        	return 0;
        }
        if(c && b) {
        	return (c1-c2)/ 12;
        }
        return 0;
    }
    



}