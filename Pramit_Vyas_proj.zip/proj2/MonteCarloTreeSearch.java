package proj2;

import java.util.ArrayList;
import java.util.Random;

/**
 * 
 * @author  Pramit Vyas
 *
 */

/**
 * This class implements the Monte Carlo tree search method to find the best
 * move at the current state.
 */
public class MonteCarloTreeSearch extends AdversarialSearch {
	private int iterations = 0;
//	private final Game<S, A, P> game;
//	private final GameTree<S, A> tree;
	/**
     * The input parameter legalMoves contains all the possible moves.
     * It contains four integers:  fromRow, fromCol, toRow, toCol
     * which represents a move from (fromRow, fromCol) to (toRow, toCol).
     * It also provides a utility method `isJump` to see whether this
     * move is a jump or a simple move.
     *
     * Each legalMove in the input now contains a single move
     * or a sequence of jumps: (rows[0], cols[0]) -> (rows[1], cols[1]) ->
     * (rows[2], cols[2]).
     *
     * @param legalMoves All the legal moves for the agent at current step.
     */
    public CheckersMove makeMove(CheckersMove[] legalMoves) {
        // The checker board state can be obtained from this.board,
        // which is an 2D array of the following integers defined below:
    	// 
        // 0 - empty square,
        // 1 - red man
        // 2 - red king
        // 3 - black man
        // 4 - black king
        System.out.println(board);
        System.out.println();

        // TODO 
        
        // Return the move for the current state.
        // Here, we simply return the first legal move for demonstration.
        return montecarlo(this.board, legalMoves, 1000);
    }
    
    // TODO
    // 
    // Implement your helper methods here. They include at least the methods for selection,  
    // expansion, simulation, and back-propagation. 
    // 
    // For representation of the search tree, you are suggested (but limited) to use a 
    // child-sibling tree already implemented in the two classes CSTree and CSNode (which  
    // you may feel free to modify).  If you decide not to use the child-sibling tree, simply 
    // remove these two classes. 
    
    private double UCB(MCNode node) {
   	 double num_playout = node.totalPlayouts; 
   	 return Math.sqrt(2) * Math.sqrt(Math.log(node.parent.totalPlayouts / node.totalPlayouts))
   			+ node.allWins / node.totalPlayouts;

    }
    

    private boolean isTerminal(CheckersData state) {
    	boolean b = false;
    	boolean c = false;
    	double c1 =0;
    	double c2=0;
    	for(int i = 0; i<state.board.length;i++) {
    		for(int j = 0; j < state.board.length; j++) {
    			if(state.board[i][j] == state.BLACK || state.board[i][j] == state.BLACK_KING) {
    				b = true;
    				c1++;
    			}
    			if(state.board[i][j] == state.RED || state.board[i][j] == state.RED_KING) {
    				c = true;
    				c2++;
    			}
    		}
    	}
    	
    	return !b || !c;
    }
    
    private MCNode selection(MCNode rt) {
    	MCNode n = rt;
  
   	 int whereat = 0; 
   	 double uct=Double.NEGATIVE_INFINITY ; 
   	 MCNode n3 = null;
    	while(n.hasChild() == true) {
    		n = n3;
			ArrayList<MCNode> n2 = n.getChildren();
					

			
	    	 double mv = Double.NEGATIVE_INFINITY; 

	    	 for(int i = 0; i < n2.size(); i++) {
	    		 uct = UCB(n2.get(i)); 
	    		 if(uct > mv) {
	    			mv = uct; 
	    			 whereat = i; 
	    		 }
	    	 }
			n3 = n2.get(whereat); 
		}
    	return n3; 
    }
    
    private boolean expand(MCNode currentNode) {
        if (currentNode.state.getLegalMoves(currentNode.opponentPlayer)
 == null) {
            return false;
        }
        CheckersMove[] all = 
        		currentNode.state.getLegalMoves(currentNode.opponentPlayer);
        CheckersData board2 = currentNode.state;
        for (CheckersMove i : all) {
        	CheckersData board68 = new CheckersData();
        	for (int row = 0; row < 8; row++){
    			for (int col = 0; col < 8; col++){
    				if (row % 2 == col % 2){
    					board68.board[row][col] = board2.pieceAt(row, col);
    				}
                }
            }   

            board68.makeMove(i);
            MCNode nextNode = new MCNode(currentNode.opponentPlayer,
            		currentNode.currentPlayer, 0, 0, board68, i);
            currentNode.addChild(nextNode);
            nextNode.setParentNode(currentNode);
        }

        return true;
    }
    
    private int simulate(MCNode node) {
    	
    	CheckersData nnn = node.state;
    	
    CheckersData news = new CheckersData();
    	for (int row = 0; row < 8; row++){
			for (int col = 0; col < 8; col++){
				if (row % 2 == col % 2){
					news.board[row][col] = nnn.pieceAt(row, col);
				}
            }}
        int ai = node.currentPlayer;
        int notai = node.opponentPlayer;
        int stepsToDraw = 40;
        int c = 0;
        int numPieces =0;
        for(int k = 0; k<news.board.length; k++) {
        	for(int e = 0; e<news.board.length; e++) {
        		if(news.board[k][e] == news.BLACK|| 
        				news.board[k][e] == news.BLACK_KING ||
        				news.board[k][e] == news.RED_KING ||
        				news.board[k][e] == news.RED) {
        			numPieces++;
        		}
        	}
        }
       c = 0;
        while (!isTerminal(news)) {
            CheckersMove[] legalMoves = 
            		news.getLegalMoves(c % 2 == 0 ? notai : ai);
          
            news.makeMove(legalMoves[new Random().nextInt(legalMoves.length)]);

            int nextnum =0;
            for(int k = 0; k<news.board.length; k++) {
            	for(int e = 0; e<news.board.length; e++) {
            		if(news.board[k][e] == news.BLACK|| 
            				news.board[k][e] == news.BLACK_KING ||
            				news.board[k][e] == news.RED_KING ||
            				news.board[k][e] == news.RED) {
            			nextnum++;
            		}
            	}
            }
            if (nextnum == numPieces) {
                stepsToDraw--;
                if (stepsToDraw <= 0) {
                    return 0;
                }
            } else {
                stepsToDraw = 40;
                numPieces = nextnum;
            }
            c++;
        }

        return (c % 2 == 0) ? 1 : -1;
    }
    	
    	
    	private void backPropogation(MCNode node, int sim) {
    	    int c = 0;

    	    while (!(node == null)) {
    	        if (c % 2 == sim) {
    	            node.allWins++;
    	        } else if (sim == 0) {
    	            node.allWins+=.5;
    	        }

    	        node.totalPlayouts++;

    	        c++;
    	        node = node.parent;
    	    }
    	}
    	private CheckersMove montecarlo(CheckersData initialGameBoard, CheckersMove[] availableActions, int sim) {
    	    MCNode treeRoot = new MCNode(initialGameBoard.RED, initialGameBoard.BLACK, 0, 0, initialGameBoard, null);

    	    for (int simIndex = 0; simIndex < sim; simIndex++) {
    	        MCNode selectedLeaf = selection(treeRoot);
    	        boolean canExtend = expand(selectedLeaf);
    	        ArrayList<MCNode> offspringNodes = selectedLeaf.children;
    	        double maxValue = Double.NEGATIVE_INFINITY;
    	        int bestChildIndex = 0;
    	        double ucbValue;

    	        for (int i = 0; i < offspringNodes.size(); i++) {
    	            ucbValue = UCB(offspringNodes.get(i));

    	            if (ucbValue > maxValue) {
    	                maxValue = ucbValue;
    	                bestChildIndex = i;
    	            }
    	        }
    	        MCNode h = (MCNode) selectedLeaf.getChildren().get(bestChildIndex);
    	        MCNode simulatedNode = canExtend ? h : selectedLeaf;
    	        int simulationOutcome = simulate(simulatedNode);
    	        this.backPropogation(simulatedNode, sim);
    	    }

    	    double highestPlayouts = 0;
    	    CheckersMove optimalMove = null;
    	    MCNode childNode = null;
    	    for (int j = 0; j<treeRoot.children.size(); j ++) {
    	    	childNode = (MCNode) treeRoot.children.get(j);
    	        double winRate = (double) childNode.allWins / (double) childNode.totalPlayouts;
    	        if (highestPlayouts < childNode.totalPlayouts) {
    	            highestPlayouts = childNode.totalPlayouts;
    	            optimalMove = childNode.moveTaken;
    	        }
    	    }

    	    return optimalMove;
    	}



    
    
    
    
    
    // 

}
