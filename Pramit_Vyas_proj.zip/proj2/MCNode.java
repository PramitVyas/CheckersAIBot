package proj2;

import java.util.ArrayList;

/**
 * Node type for the Monte Carlo search tree.
 * @author Pramit Vyas
 */
public class MCNode<E>
{
  // TODO  

//	
//	/**
//	 * Returns the state in the state space to which the node corresponds.
//	 * 
//	 * @return the state in the state space to which the node corresponds.
//	 */
//	public CheckersData getState() {
//		return state;
//	}
//	
	
	public MCNode(int currentPlayer, int opponentPlayer, int totalWins, int totalPlayouts, 
			CheckersData gameState, CheckersMove moveTaken) {this.currentPlayer = currentPlayer;
	    this.opponentPlayer = opponentPlayer;
	    this.allWins = totalWins;
	    this.totalPlayouts = totalPlayouts;
	    //this.state = state;
	    this.moveTaken = moveTaken;
		state = gameState;
		this.pathCost = 0;}
//	/**
//	 * Returns this node's parent node, from which this node was generated.
//	 * 
//	 * @return the node's parenet node, from which this node was generated.
//	 */
//	public MCNode<E> getParent() {
//		return parent;
//	}
//	
//	/**
//	 * Returns the action that was applied to the parent to generate the node.
//	 * 
//	 * @return the action that was applied to the parent to generate the node.
//	 */
//	public CheckersMove getAction() {
//		return action;
//	}
//	
//	
//	/**
//	 * Returns the cost of the path from the initial state to this node as
//	 * indicated by the parent pointers.
//	 * 
//	 * @return the cost of the path from the initial state to this node as
//	 *         indicated by the parent pointers.
//	 */
//	public double getPathCost() {
//		return pathCost;
//	}
//	
//	/**
//	 * Returns <code>true</code> if the node has no parent.
//	 * 
//	 * @return <code>true</code> if the node has no parent.
//	 */
//	public boolean isRootNode() {
//		return parent == null;
//	}
//	
//	public int getDepth() {
//		return depth;
//	}

//	
//	public double calculateUCTValue(double explorationParameter) {
//	    if (isRoot() || getNumberOfVisits() == 0) {
//	        return Double.POSITIVE_INFINITY;
//	    }
//	    double exploitation = getNodeValue() / getNumberOfVisits();
//	    double exploration = explorationParameter * Math.sqrt(Math.log(getParent().getNumberOfVisits()) / getNumberOfVisits());
//	    return exploitation + exploration;
//	}
//
//	public double getNodeValue() {
//	    return value;
//	}
//
//	public MCTSNode setNodeValue(double value) {
//	    this.value = value;
//	    return getThis();
//	}
//
//	public int getNumberOfVisits() {
//	    return visits;
//	}
//
//	public MCTSNode setNumberOfVisits(int visits) {
//	    this.visits = visits;
//	    return getThis();
//	}
//
//	/**
//	 * Must be implemented per the abstract class Node.
//	 *
//	 * @return This node
//	 */
//	public MCTSNode getThis() {
//	    return this;
//	}

	
	// n.STATE: the state in the state space to which the node corresponds;
	public final CheckersData state;

	// n.PARENT: the node in the search tree that generated this node;
	public MCNode<E> parent;

	// n.ACTION: the action that was applied to the parent to generate the node;
	//private final CheckersMove action;

	// n.PATH-COST: the cost, traditionally denoted by g(n), of the path from
	// the initial state to the node, as indicated by the parent pointers.
	public final double pathCost;

	//private final int depth;
	
	

	public CheckersMove moveTaken;		
	public ArrayList<MCNode> children= new ArrayList<MCNode>();		
	public int currentPlayer = 0;	
	public int opponentPlayer = 0;		
	public double allWins = 0;		
	public double totalPlayouts = 0;	
	public MCNode(CheckersData state) {
		this(0,0,0,0,state, null);
	}

	public void setParentNode(MCNode parentNode) { parent = parentNode; }
	public boolean hasChild() { return (!(children.size() <= 0) && (children.size()> -3)); }
	public ArrayList<MCNode> getChildren() { return children; }
	public void addChild(MCNode nextState) { children.add(nextState); }


	
	

}

